package com.company;

public class Main {

    public static void main(String[] args) {
        Cinema cinema = new Cinema();



        cinema.cineProgramm();
        System.out.println();
        cinema.saalAnsicht();
        System.out.println();
        cinema.resavierung();
        cinema.reservierungsOutput();

//        cinema.platzauswahl(3);


       // cinema.ticketCanceling();




    }
}
