package com.company;

import java.sql.*;
import java.util.Scanner;

public class Delivery {
    Connection conn = null;
    String url = "jdbc:mysql://localhost:3306/lieferservice?user=root";
    Scanner scanner = new Scanner(System.in);
    int userID;
    int logInCounter = 0;





    public void logIn (Customer customer) {

        try {
            System.out.println("Willkommen bei QuickFood\nEinlogen (1) oder Account erstellen (2) ?");
            String choice = scanner.nextLine();
            if (choice.equalsIgnoreCase("2")){
                customer.createUser();
            } else {
                System.out.println("Email eingeben");
                String userEmail = scanner.nextLine();
                System.out.println("Bitte Passwort eingeben");
                String password = scanner.nextLine();
                if (!customer.isRightLogin(userEmail,password)) {
                    System.out.println("Falsche Login Daten");
                    this.logInCounter++;

                    if (this.logInCounter % 3 == 0) {
                        System.out.println("Bitte geben Sie UserID, Email und Wohnort an für Account Detials");

                        System.out.println("UserID");
                        int userID = scanner.nextInt();

                        System.out.println("Email");
                        String enter = scanner.nextLine();
                        String userEMail = scanner.nextLine();


                        System.out.println("Wohnort");
                        String place = scanner.nextLine();

                        customer.custAccInfo(userID,userEMail,place);
                        logIn(customer);
                    }
                    logIn(customer);
                } else {
                    conn = DriverManager.getConnection(url);
                    Statement stmt = null;

                    String query = "SELECT  `user_id` FROM `user` Where user.email = '" + userEmail + "'";


                    try {
                        stmt = conn.createStatement();
                        ResultSet rs = stmt.executeQuery(query);

                        while (rs.next()) {
                            int userID = rs.getInt("user_id");
                            this.userID = userID;
                            System.out.println("loged in");


                        }


                    } catch (SQLException e) {
                        throw new Error("Problem ", e);
                    } finally {
                        try {
                            if (stmt != null)
                                stmt.close();
                        } catch (SQLException ex) {
                            System.out.println(ex.getMessage());
                        }
                    }
                }



            }
        } catch (SQLException e) {
            throw new Error("Problem " , e);
        } finally {
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }


}
