package com.company;

public class Main {

    public static void main(String[] args) {
        Customer customer = new Customer();
        //customer.custAccInfo(1, "luca.windisch@gmx.at", "Nenzing");
        Delivery delivery = new Delivery();

        delivery.logIn(customer);

    }
}
