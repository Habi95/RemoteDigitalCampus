package com.company.Database.repository;

import com.company.DataBaseConnector;

public class DB_Connector extends DataBaseConnector {
    public DB_Connector(String url) {
        super(url);
    }
}
